import multiprocessing
import redis
import json
from datetime import datetime, timedelta


def handler(input: dict, context: object) -> dict:
    
    cpu_count = multiprocessing.cpu_count()

    p_traffic = (input['net_io_counters_eth0-bytes_sent'] * 100) / (input['net_io_counters_eth0-bytes_sent'] + input['net_io_counters_eth0-bytes_recv'])
    p_memory = ((input['virtual_memory-cached'] + input['virtual_memory-buffers']) * 100) / input['virtual_memory-total']
    
    
    end_time = datetime.now() + timedelta(seconds=60)  # Limite de 60 segundos
    current_time = datetime.now()
    
    p_use_cpu = dict()
    
    for index in range(cpu_count):
        p_use_cpu[index] = 0
    
    len_ = 0
    while(current_time < end_time):
        current_time = datetime.now()
        len_ = len_ + 1
        for index in range(cpu_count):
            p_use_cpu[index] = (input[f'cpu_percent-{index}'] + p_use_cpu[index])
    

    resp = dict()
    
    resp["cpu_count"] = cpu_count
    resp['p_trafic'] = p_traffic
    resp['p_memory'] =  p_memory
    
    for index in range(cpu_count):
        m_avg = p_use_cpu[index]/len_
        resp[f"avg-util-cpu{index}-60sec"] = m_avg
    
    return resp